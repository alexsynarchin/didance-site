--------------------
videoGallery
--------------------
Author: Pavel Gvozdb <pa6ok.ru>
--------------------

Видеогалерея для MODX Revo.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/gvozdb/videoGallery/issues
