<?php
class msCategoryMember extends xPDOObject {}