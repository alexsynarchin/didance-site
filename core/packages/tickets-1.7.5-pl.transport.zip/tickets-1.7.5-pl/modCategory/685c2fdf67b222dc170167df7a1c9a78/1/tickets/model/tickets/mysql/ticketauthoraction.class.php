<?php
require_once (dirname(dirname(__FILE__)) . '/ticketauthoraction.class.php');
class TicketAuthorAction_mysql extends TicketAuthorAction {}