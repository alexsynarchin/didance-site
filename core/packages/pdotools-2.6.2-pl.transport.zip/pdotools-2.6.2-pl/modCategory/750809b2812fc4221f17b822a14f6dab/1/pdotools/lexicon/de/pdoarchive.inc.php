<?php
/**
 * pdoPage Russian Lexicon Entries for pdoArchive
 *
 * @package pdotools
 * @subpackage lexicon
 * @language de
 */

$_lang['pdoarchive_month_01'] = 'Januar';
$_lang['pdoarchive_month_02'] = 'Februar';
$_lang['pdoarchive_month_03'] = 'März';
$_lang['pdoarchive_month_04'] = 'April';
$_lang['pdoarchive_month_05'] = 'Mai';
$_lang['pdoarchive_month_06'] = 'Juni';
$_lang['pdoarchive_month_07'] = 'Jul';
$_lang['pdoarchive_month_08'] = 'August';
$_lang['pdoarchive_month_09'] = 'September';
$_lang['pdoarchive_month_10'] = 'Oktober';
$_lang['pdoarchive_month_11'] = 'November';
$_lang['pdoarchive_month_12'] = 'Dezember';
