<?php

include_once 'setting.inc.php';

$_lang['mspyacassa'] = 'mspyacassa';

$_lang['mspyacassa_tab_add'] = 'Дополнительно';
$_lang['mspyacassa_tab_payment'] = 'Оплата';

$_lang['mspyacassa_properties'] = 'Свойства';

$_lang['mspyacassa_email_subject_onhold_user'] = 'Заказ #[[+num]] был забронирован';

/* Errors */
$_lang['mspyacassa_err_system'] = 'Системная ошибка';
$_lang['mspyacassa_err_unknown'] = 'Неизвестная ошибка';

$_lang['mspyacassa_err_confirm_payment'] = 'Не удалось подтвердить перевод средств!';
$_lang['mspyacassa_err_cancel_payment'] = 'Не удалось аннулировать платеж!';


