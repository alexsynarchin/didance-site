--------------------
mspYaCassa
--------------------
Author: Vgrish <vgrish@gmail.com>
--------------------
