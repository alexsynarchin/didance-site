<?php

require_once dirname(dirname(dirname(__FILE__))) . '/mspyacassa/controllers/minishop2hold.php';
