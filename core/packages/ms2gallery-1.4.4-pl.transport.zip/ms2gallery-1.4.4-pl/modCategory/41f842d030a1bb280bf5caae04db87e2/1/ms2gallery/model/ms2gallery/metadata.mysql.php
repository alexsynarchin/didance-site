<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'msResourceFile',
  ),
  'xPDOObject' => 
  array (
    0 => 'msResourceFileTag',
  ),
);