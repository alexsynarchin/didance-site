<?php
/*
$_lang['videogallery_prop_name'] = 'Параметр для страницы настроек ТВ';
$_lang['videogallery_prop_name_desc'] = '';
*/