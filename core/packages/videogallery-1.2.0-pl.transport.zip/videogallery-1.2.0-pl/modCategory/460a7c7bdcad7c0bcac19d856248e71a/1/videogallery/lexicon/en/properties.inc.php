<?php

$_lang['videogallery_prop_tv'] = 'Название ТВ поля. Обязательно, если не передан параметр "tvId"';
$_lang['videogallery_prop_tvId'] = 'ID ТВ поля. Обязательно, если не передан параметр "tv"';
$_lang['videogallery_prop_tvInput'] = 'Название input поля, которое пишется в атрибут input[name=""]. Не обязательно. По умолчанию пишется название ТВ.';
$_lang['videogallery_prop_res'] = 'ID ресурса, у которого получать ТВ';
$_lang['videogallery_prop_tpl'] = 'Чанк для вывода';
