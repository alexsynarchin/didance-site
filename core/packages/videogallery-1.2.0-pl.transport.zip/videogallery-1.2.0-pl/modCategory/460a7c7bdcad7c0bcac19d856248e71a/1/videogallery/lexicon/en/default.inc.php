<?php

include_once 'setting.inc.php';

$_lang['videogallery'] = 'videoGallery';
$_lang['videogallery_menu_desc'] = 'Компонент видео галереи.';

$_lang['videogallery_pdotools_install'] = 'Установите pdoTools';


// >> Ошибки
$_lang['videogallery_err_ns'] = 'Вы забыли указать ссылку на видео.';
$_lang['videogallery_err_nf'] = 'Не могу найти видео, может - неверная ссылка?';
$_lang['videogallery_item_err_undefined'] = 'Неизвестная ошибка. Проверьте ссылку на ошибки и попытайтесь ещё раз.';
// << Ошибки